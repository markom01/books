module.exports = {
  alias: {
    "@mui/base": "@mui/base/modern",
    "@mui/lab": "@mui/lab/modern",
    "@mui/material": "@mui/material/modern",
    "@mui/styled-engine": "@mui/styled-engine/modern",
    "@mui/system": "@mui/system/modern",
    "@mui/utils": "@mui/utils/modern",
  },
};
